para rodar o projeto 

necessario ter o docker desktop!

no terminal rodar

## docker-compose build
 
depois :

## docker-compose up




para rodar o .jar , na pasta onde esta o .jar , rodar o comando 

##  java -jar compiladores2.jar
